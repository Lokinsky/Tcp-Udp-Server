﻿using ConsoleApp3;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1.Controllers
{
    class Chat : IController
    {
        public object executeController(IConnection clientObj, StateObject sObject, IDictionary<string, object> payload)
        {
            throw new NotImplementedException();
        }
    }
}
